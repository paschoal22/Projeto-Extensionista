import React, { useContext } from 'react';
import { View, Text, FlatList, TouchableOpacity, Image, StyleSheet } from 'react-native';
import { CartContext } from './CarrinhoConteudo';

export default function CartScreen({ navigation }) {
  const { cartItems, incrementQuantity, decrementQuantity, removeFromCart, getTotalPrice } = useContext(CartContext);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Carrinho de Compras</Text>
      {cartItems.length === 0 ? (
        <Text style={styles.emptyMessage}>O carrinho está vazio!</Text>
      ) : (
        <>
          <FlatList
            data={cartItems}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.cartItem}>
                <Image source={{ uri: item.image }} style={styles.productImage} />
                <View style={styles.cartItemDetails}>
                  <Text style={styles.productName}>{item.name}</Text>
                  <Text>R$ {item.price}</Text>
                  <Text>Quantidade: {item.quantity}</Text>
                  <View style={styles.quantityButtons}>
                    <TouchableOpacity onPress={() => decrementQuantity(item.id)} style={styles.quantityButton}>
                      <Text style={styles.quantityButtonText}>-</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => incrementQuantity(item.id)} style={styles.quantityButton}>
                      <Text style={styles.quantityButtonText}>+</Text>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => removeFromCart(item.id)} style={styles.removeButton}>
                      <Text style={styles.removeButtonText}>Remover</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            )}
          />
          <Text style={styles.totalText}>Total: R$ {getTotalPrice()}</Text>
        </>
      )}

      <TouchableOpacity style={styles.continueButton} onPress={() => navigation.navigate('Home')}>
        <Text style={styles.continueButtonText}>Continuar Comprando</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.paymentButton} onPress={() => navigation.navigate('Login')}>
        <Text style={styles.paymentButtonText}>Ir para Pagamento</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f0f4ff' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  emptyMessage: { fontSize: 18, color: '#999' },
  cartItem: {
    flexDirection: 'row',
    marginVertical: 10,
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 15,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  productImage: {
    width: 100,
    height: 100,
    borderRadius: 10,
    marginRight: 15,
  },
  cartItemDetails: {
    flex: 1,
    justifyContent: 'space-between',
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  quantityButtons: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
  },
  quantityButton: {
    backgroundColor: '#ff66b2', 
    borderRadius: 15,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginHorizontal: 5,
  },
  quantityButtonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
  removeButton: {
    marginLeft: 20,
    backgroundColor: '#d9534f', // Vermelho
    borderRadius: 15,
    paddingVertical: 8,
    paddingHorizontal: 15,
  },
  removeButtonText: {
    fontSize: 14,
    color: '#fff',
    fontWeight: 'bold',
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'right',
    marginTop: 20,
    color: '#333',
  },
  continueButton: {
    marginTop: 20,
    backgroundColor: '#0056b3',
    paddingVertical: 12,
    borderRadius: 25, // Arredondando mais o botão
    alignItems: 'center',
  },
  continueButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  paymentButton: {
    marginTop: 10,
    backgroundColor: '#28a745',
    paddingVertical: 12,
    borderRadius: 25, // Arredondando mais o botão
    alignItems: 'center',
  },
  paymentButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});
