const express = require('express');
const Pedido = require('../models/Pedido');
const router = express.Router();

router.get('/', async (req, res) => {
  const pedidos = await Pedido.find();
  res.json(pedidos);
});

module.exports = router;
