const mongoose = require('mongoose');

const usuarioSchema = new mongoose.Schema({
  nome: String,
  email: String,
  senha: String,
  endereco: String,
  telefone: String,
});

module.exports = mongoose.model('Usuario', usuarioSchema);
