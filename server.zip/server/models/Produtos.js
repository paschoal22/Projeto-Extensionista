const mongoose = require('mongoose');

const produtoSchema = new mongoose.Schema({
  nome: String,
  descricao: String,
  preco: Number,
  categoria: String,
  estoque: Number,
});

module.exports = mongoose.model('Produto', produtoSchema);
