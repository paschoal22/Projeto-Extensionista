const mongoose = require('mongoose');

const pedidoSchema = new mongoose.Schema({
  usuario_id: String,
  produtos: [{ produto_id: String, quantidade: Number }],
  total: Number,
  status: String,
  data: Date,
});

module.exports = mongoose.model('Pedido', pedidoSchema);
