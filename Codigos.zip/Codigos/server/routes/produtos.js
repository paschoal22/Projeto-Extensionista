const express = require('express');
const Produto = require('../models/Produto');
const router = express.Router();

router.get('/', async (req, res) => {
  const produtos = await Produto.find();
  res.json(produtos);
});

module.exports = router;
