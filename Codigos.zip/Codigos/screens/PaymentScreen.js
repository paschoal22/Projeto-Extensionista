import React, { useContext } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, Image, ScrollView } from 'react-native';
import { CartContext } from './CarrinhoConteudo'; 

const PaymentScreen = ({ navigation }) => {
  const { getTotalPrice, cartItems } = useContext(CartContext); 
  const totalPrice = getTotalPrice(); 

  const handlePayment = (method) => {
    Alert.alert('Pagamento', `Método de pagamento selecionado: ${method}`);
    
    navigation.navigate('Home');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.message}>Escolha um método de pagamento:</Text>
      <Text style={styles.total}>Total da Compra: R$ {totalPrice}</Text>

      
      <View style={styles.productsContainer}>
        {cartItems.map((item) => (
          <View key={item.id} style={styles.productCard}>
            <Image source={{ uri: item.image }} style={styles.productImage} />
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>R$ {item.price} x {item.quantity}</Text>
          </View>
        ))}
      </View>

      <View style={styles.buttonsContainer}>
        <TouchableOpacity style={styles.button} onPress={() => handlePayment('Cartão de Crédito')}>
          <Text style={styles.buttonText}>Cartão de Crédito</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => handlePayment('PIX')}>
          <Text style={styles.buttonText}>PIX</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => handlePayment('Boleto')}>
          <Text style={styles.buttonText}>Boleto</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { 
    flexGrow: 1, 
    padding: 20, 
    backgroundColor: '#f0f4ff' 
  },
  message: { 
    fontSize: 20, 
    fontWeight: 'bold', 
    marginBottom: 10, 
    textAlign: 'center', 
    marginTop: 20, 
  },
  total: {
    fontSize: 20, 
    fontWeight: 'bold', 
    marginBottom: 20,
    textAlign: 'center', 
  },
  productsContainer: {
    marginBottom: 20, 
    borderRadius: 10, 
    padding: 10,
    backgroundColor: '#fff', 
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  productCard: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    padding: 10,
    borderRadius: 8,
    backgroundColor: '#e8f0ff',
  },
  productImage: {
    width: 50, 
    height: 50, 
    borderRadius: 5, 
    marginRight: 10,
  },
  productName: {
    fontSize: 16, 
    flex: 1, 
    color: '#333',
  },
  productPrice: {
    fontSize: 14, 
    color: '#666',
  },
  buttonsContainer: {
    marginTop: 20,
  },
  button: {
    backgroundColor: '#0056b3', 
    paddingVertical: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  buttonText: { 
    color: '#fff', 
    textAlign: 'center' 
  },
});

export default PaymentScreen;

