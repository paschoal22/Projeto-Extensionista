import React, { useContext } from 'react';
import { View, Text, Image, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { CartContext } from './CarrinhoConteudo';

const bannerImage = 'https://www.designi.com.br/images/preview/10029475.jpg';

const featuredProducts = [
  { id: '1', name: 'Caderno Espiral', price: '15.00', image: 'https://m.media-amazon.com/images/I/71HQIdGbyfL._AC_SL1000_.jpg' },
  { id: '2', name: 'Estojo Organizador', price: '25.00', image: 'https://m.media-amazon.com/images/I/51iaNFNW2CL._AC_SL1200_.jpg' },
  { id: '3', name: 'Planner 2023', price: '35.00', image: 'https://m.media-amazon.com/images/I/7115rbu2NcL._AC_SL1500_.jpg' },
  { id: '4', name: 'Caneta Esferográfica', price: '5.00', image: 'https://m.media-amazon.com/images/I/51WUFXRfNyL._AC_SL1024_.jpg' },
  { id: '5', name: 'Bloco de Notas', price: '10.00', image: 'https://m.media-amazon.com/images/I/61ItUabigtL._AC_SL1463_.jpg' },
];

export default function HomeScreen({ navigation }) {
  const { addToCart } = useContext(CartContext);

  const handleAddToCart = (item) => {
    addToCart(item);
    navigation.navigate('Cart'); 
  };

  return (
    <View style={styles.container}>
    
      <Image source={{ uri: bannerImage }} style={styles.bannerImage} />

      <View style={styles.banner}>
        <Text style={styles.bannerText}>Volta às Aulas</Text>
      </View>

      <Text style={styles.sectionTitle}>Produtos em Destaque</Text>
      <FlatList
        data={featuredProducts}
        numColumns={2}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.product}>
            <Image source={{ uri: item.image }} style={styles.productImage} />
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>R$ {item.price}</Text>
            <TouchableOpacity style={styles.addButton} onPress={() => handleAddToCart(item)}>
              <Text style={styles.addButtonText}>Adicionar ao Carrinho</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f0f4ff', 
  },
  bannerImage: {
    width: '100%',
    height: 200, 
    borderRadius: 15,
    marginBottom: 20,
  },
  banner: {
    backgroundColor: '#e8f0ff',
    padding: 20,
    marginBottom: 20,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 5,
  },
  bannerText: {
    fontSize: 24,
    textAlign: 'center',
    fontWeight: 'bold',
    color: '#333',
  },
  sectionTitle: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  product: {
    flex: 1,
    alignItems: 'center',
    margin: 8,
    padding: 15,
    backgroundColor: '#fff',
    borderRadius: 15,
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 5,
  },
  productImage: {
    width: 120,
    height: 120,
    borderRadius: 10,
    marginBottom: 5,
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  productPrice: {
    fontSize: 16,
    color: '#666',
    marginVertical: 5,
  },
  addButton: {
    marginTop: 10,
    backgroundColor: '#ff66b2', 
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 25, 
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 10,
    elevation: 3,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});

