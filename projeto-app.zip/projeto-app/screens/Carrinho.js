// screens/CartScreen.js
import React, { useContext } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { CartContext } from './CarrinhoConteudo';

export default function CartScreen({ navigation }) {
  const { cartItems } = useContext(CartContext);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Carrinho de Compras</Text>
      {cartItems.length === 0 ? (
        <Text style={styles.emptyMessage}>O carrinho está vazio!</Text>
      ) : (
        <FlatList
          data={cartItems}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => (
            <View style={styles.cartItem}>
              <Text>{item.name} - R$ {item.price}</Text>
              <Text>Quantidade: {item.quantity}</Text>
            </View>
          )}
        />
      )}
      
      <TouchableOpacity style={styles.continueButton} onPress={() => navigation.navigate('Home')}>
        <Text style={styles.continueButtonText}>Continuar Comprando</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.paymentButton} onPress={() => navigation.navigate('Login')}>
        <Text style={styles.paymentButtonText}>Ir para Pagamento</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f0f4ff' }, // Azul claro
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  emptyMessage: { fontSize: 18, color: '#999' },
  cartItem: { marginVertical: 10, padding: 10, backgroundColor: '#fff', borderRadius: 5 },
  continueButton: {
    marginTop: 20,
    backgroundColor: '#0056b3', // Azul escuro
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  continueButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
  paymentButton: {
    marginTop: 10,
    backgroundColor: '#28a745', // Verde
    paddingVertical: 10,
    borderRadius: 5,
    alignItems: 'center',
  },
  paymentButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});

