import React, { useContext } from 'react';
import { View, Text, Image, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { CartContext } from './CarrinhoConteudo';

const featuredProducts = [
  { id: '1', name: 'Caderno Espiral', price: '15.00', image: 'https://via.placeholder.com/100' },
  { id: '2', name: 'Estojo Organizador', price: '25.00', image: 'https://via.placeholder.com/100' },
  { id: '3', name: 'Planner 2023', price: '35.00', image: 'https://via.placeholder.com/100' },
  { id: '4', name: 'Caneta Esferográfica', price: '5.00', image: 'https://via.placeholder.com/100' },
  { id: '5', name: 'Bloco de Notas', price: '10.00', image: 'https://via.placeholder.com/100' },
];

export default function HomeScreen({ navigation }) {
  const { addToCart } = useContext(CartContext);

  const handleAddToCart = (item) => {
    addToCart(item);
    navigation.navigate('Cart'); // Navega para a tela do carrinho
  };

  return (
    <View style={styles.container}>
      <View style={styles.banner}>
        <Text style={styles.bannerText}>Bem-vindo à Papelaria Ninas</Text>
      </View>
      <Text style={styles.sectionTitle}>Produtos em Destaque</Text>
      <FlatList
        data={featuredProducts}
        numColumns={2}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.product}>
            <Image source={{ uri: item.image }} style={styles.productImage} />
            <Text style={styles.productName}>{item.name}</Text>
            <Text style={styles.productPrice}>R$ {item.price}</Text>
            <TouchableOpacity style={styles.addButton} onPress={() => handleAddToCart(item)}>
              <Text style={styles.addButtonText}>Adicionar ao Carrinho</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#f0f4ff' }, // Azul claro
  banner: { backgroundColor: '#e8f0ff', padding: 20, marginBottom: 20, borderRadius: 10 },
  bannerText: { fontSize: 18, textAlign: 'center', fontWeight: 'bold', color: '#333' },
  sectionTitle: { fontSize: 22, fontWeight: 'bold', marginBottom: 10, color: '#333' },
  product: {
    flex: 1,
    alignItems: 'center',
    margin: 8,
    padding: 10,
    backgroundColor: '#fff',
    borderRadius: 10,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowRadius: 10,
    elevation: 5,
  },
  productImage: { width: 100, height: 100, borderRadius: 8, marginBottom: 5 },
  productName: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  productPrice: { fontSize: 14, color: '#666', marginVertical: 5 },
  addButton: {
    marginTop: 10,
    backgroundColor: '#0056b3', // Azul escuro
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 5,
  },
  addButtonText: { color: '#fff', fontSize: 14, fontWeight: 'bold' },
});
