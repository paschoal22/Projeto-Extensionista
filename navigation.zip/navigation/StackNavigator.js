import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import TelaInicial from '../screens/TelaInicial';
import Carrinho from '../screens/Carrinho';
import TelaLogin from '../screens/TelaLogin';
import PaymentScreen from '../screens/PaymentScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <CartProvider>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home">
          <Stack.Screen name="Home" component={TelaInicial} />
          <Stack.Screen name="Cart" component={Carrinho} />
          <Stack.Screen name="TelaLogin" component={TelaLogin} />
          <Stack.Screen name="Payment" component={PaymentScreen} />
        </Stack.Navigator>
      </NavigationContainer>
    </CartProvider>
  );
}
